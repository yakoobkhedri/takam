﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'pt-br', {
    WordCount: 'Contagem de palavras:',
    WordCountRemaining: 'Palavras restantes',
    CharCount: 'Contagem de caracteres:',
    CharCountRemaining: 'Caracteres restantes',
    CharCountWithHTML: 'Caracteres (incluindo HTML):',
    CharCountWithHTMLRemaining: 'Caracteres (com HTML) restantes',
    Paragraphs: 'Parágrafos:',
    ParagraphsRemaining: 'Parágrafos restantes',
    pasteWarning: 'Conteúdo não pode ser colado porque ultrapassa o limite permitido',
    Selected: 'Selecionado: ',
    title: 'Estatísticas'
});
