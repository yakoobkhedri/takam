﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'ja', {
    WordCount: '単語数:',
    WordCountRemaining: 'Words remaining',
    CharCount: '文字数:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: '文字数 (HTMLタグを含む):',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: '段落数:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: '文字数/単語数の上限を超えるため、貼り付けできません。',
    Selected: '選択中の字数:',
    title: 'ワードカウント'
});
