// Arabic Translation by Amine BENHAMIDA

CKEDITOR.plugins.setLang('wordcount', 'ar', {
    WordCount: 'كلمات:',
    WordCountRemaining: 'Words remaining',
    CharCount: 'حروف:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: 'حروف مع إتش تي إم إل',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: 'فقرات',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'لا يمكن اضافة هذا المحتوى لانه تجاوز الحد الاقصى',
    Selected: 'محدد: ',
    title: 'احصائيات'
});
